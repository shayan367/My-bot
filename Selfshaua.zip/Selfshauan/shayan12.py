import os
import sys
import subprocess

# ══════════════════════════════════════════════
#        نصب خودکار پکیج‌ها (برای هاست‌ها)
# ══════════════════════════════════════════════
try:
    import telegram
    import telethon
except ImportError:
    print("⏳ در حال نصب پکیج‌های لازم...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-telegram-bot==20.7", "telethon==1.34.0"])

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler, CallbackQueryHandler
)
from telegram.constants import ParseMode
from telethon import TelegramClient, functions, events
from telethon.sessions import StringSession
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.account import UpdateStatusRequest
import asyncio
import secrets
import os
import sqlite3
import random
import shutil
from datetime import datetime

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════
#                   تنظیمات
# ══════════════════════════════════════════════
BOT_TOKEN = "9106560551:AAHzO6ve6Zew8cZqJ27fYi6h-F00com95Nc"
API_ID = 31810107
API_HASH = "003587c1e56a7516245587cf2cbab8c2"

OWNER_ID = 8571312544
COIN_PRICE = 200
SELF_ACTIVATION_COST = 3
REFERRAL_BONUS = 7
WELCOME_BONUS = 3
MAX_COINS_PER_PURCHASE = 1000
SUPPORT_LINK = "https://t.me/ATUH_shad"
CARD_NUMBER = "6219 8613 5287 8747"
CARD_OWNER = "شایان محمدی"

DB_DIR = os.path.join(os.getcwd(), 'bot_data')
os.makedirs(DB_DIR, exist_ok=True)
DB_PATH = os.path.join(DB_DIR, 'users.db')

GET_PHONE, GET_CODE, GET_PASSWORD, ADD_CRASH, ADD_ENEMY, SEND_PM, SET_AUTOREPLY = range(7)

FONTS = [
    "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡", "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟟𝟴𝟵", "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿",
    "₀₁₂₃₄₅₆₇₈₉", "0123456789", "０１２３４５６７８９",
    "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗", "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡",
    "🄌➀➁➂➃➄➅➆➇➈", "⓪①②③④⑤⑥⑦⑧⑨"
]


class TelegramAuthBot:
    def __init__(self):
        self.application = Application.builder().token(BOT_TOKEN).build()
        self.user_sessions = {}
        self.owner_id = OWNER_ID
        self.db_path = DB_PATH
        self.user_clients = {}
        self.bg_tasks = {}
        
        self.init_database()
        self.setup_handlers()
        logger.info(f"✅ ربات راه‌اندازی شد | مالک: {self.owner_id}")

    def get_db(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def init_database(self):
        conn = self.get_db()
        cursor = conn.cursor()
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, coins INTEGER DEFAULT 0, join_date TEXT)''')

        existing_cols = {row[1] for row in cursor.execute("PRAGMA table_info(users)").fetchall()}
        new_columns = {
            'username': 'TEXT', 'first_name': 'TEXT', 'phone': 'TEXT',
            'invited_by': 'INTEGER', 'is_selfbot_active': 'INTEGER DEFAULT 0',
            'session_string': 'TEXT', 'timename': 'INTEGER DEFAULT 0',
            'timebio': 'INTEGER DEFAULT 0', 'online_status': 'INTEGER DEFAULT 1',
            'font': 'INTEGER DEFAULT 1', 'original_last_name': 'TEXT',
            'original_bio': 'TEXT', 'forward_pm': 'INTEGER DEFAULT 0',
            'typing_action': 'INTEGER DEFAULT 0', 'read_receipts': 'INTEGER DEFAULT 0',
            'auto_reply': 'INTEGER DEFAULT 0', 'auto_reply_text': 'TEXT',
            'hidden_typing': 'INTEGER DEFAULT 0', 'anti_delete': 'INTEGER DEFAULT 0',
            'stats_messages': 'INTEGER DEFAULT 0',
        }
        for col, typ in new_columns.items():
            if col not in existing_cols:
                try: cursor.execute(f'ALTER TABLE users ADD COLUMN {col} {typ}')
                except sqlite3.OperationalError: pass

        cursor.execute('''CREATE TABLE IF NOT EXISTS invite_links (
            invite_code TEXT PRIMARY KEY, owner_id INTEGER NOT NULL, uses INTEGER DEFAULT 0)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT, referrer_id INTEGER NOT NULL,
            referred_id INTEGER NOT NULL UNIQUE, bonus INTEGER DEFAULT 0)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL, type TEXT NOT NULL, description TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS crash (user_id INTEGER, owner_id INTEGER, PRIMARY KEY(user_id, owner_id))''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS enemy (user_id INTEGER, owner_id INTEGER, PRIMARY KEY(user_id, owner_id))''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            coin_amount INTEGER NOT NULL, total_price INTEGER NOT NULL,
            status TEXT DEFAULT 'pending', receipt_file_id TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, approved_at TEXT)''')

        conn.commit()
        conn.close()

    def ensure_user(self, user_id: int, username: str = None, first_name: str = None):
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT user_id FROM users WHERE user_id = ?', (user_id,))
        if not cursor.fetchone():
            cursor.execute('INSERT INTO users (user_id, username, first_name, coins, join_date) VALUES (?, ?, ?, 0, ?)',
                           (user_id, username, first_name, datetime.now().isoformat()))
        else:
            cursor.execute('UPDATE users SET username = ?, first_name = ? WHERE user_id = ?', (username, first_name, user_id))
        conn.commit()
        conn.close()

    def get_user(self, user_id: int):
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        row = cursor.fetchone()
        conn.close()
        return row

    def update_user(self, user_id: int, **kwargs):
        if not kwargs: return
        conn = self.get_db()
        cursor = conn.cursor()
        fields = ', '.join([f"{k} = ?" for k in kwargs.keys()])
        values = list(kwargs.values()) + [user_id]
        cursor.execute(f'UPDATE users SET {fields} WHERE user_id = ?', values)
        conn.commit()
        conn.close()

    def get_coins(self, user_id: int) -> int:
        row = self.get_user(user_id)
        return row['coins'] if row else 0

    def add_coins(self, user_id: int, amount: int, tx_type: str = 'manual', description: str = "") -> bool:
        conn = self.get_db()
        cursor = conn.cursor()
        try:
            cursor.execute('UPDATE users SET coins = coins + ? WHERE user_id = ?', (amount, user_id))
            if cursor.rowcount == 0:
                cursor.execute('INSERT INTO users (user_id, coins, join_date) VALUES (?, ?, ?)', (user_id, amount, datetime.now().isoformat()))
            cursor.execute('INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)', (user_id, amount, tx_type, description))
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            return False
        finally:
            conn.close()

    def deduct_coins(self, user_id: int, amount: int, tx_type: str = 'manual', description: str = "") -> bool:
        if self.get_coins(user_id) < amount: return False
        conn = self.get_db()
        cursor = conn.cursor()
        try:
            cursor.execute('UPDATE users SET coins = coins - ? WHERE user_id = ?', (amount, user_id))
            cursor.execute('INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)', (user_id, -amount, tx_type, description))
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            return False
        finally:
            conn.close()

    def get_or_create_invite_link(self, user_id: int, bot_username: str) -> str:
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT invite_code FROM invite_links WHERE owner_id = ?', (user_id,))
        row = cursor.fetchone()
        if row: code = row['invite_code']
        else:
            code = secrets.token_urlsafe(8)
            cursor.execute('INSERT INTO invite_links (invite_code, owner_id) VALUES (?, ?)', (code, user_id))
            conn.commit()
        conn.close()
        return f"https://t.me/{bot_username}?start={code}"

    def process_referral(self, new_user_id: int, invite_code: str):
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT owner_id FROM invite_links WHERE invite_code = ?', (invite_code,))
        row = cursor.fetchone()
        if not row: conn.close(); return None
        referrer_id = row['owner_id']
        if referrer_id == new_user_id: conn.close(); return None
        cursor.execute('SELECT id FROM referrals WHERE referred_id = ?', (new_user_id,))
        if cursor.fetchone(): conn.close(); return None
        cursor.execute('INSERT INTO referrals (referrer_id, referred_id, bonus) VALUES (?, ?, ?)', (referrer_id, new_user_id, REFERRAL_BONUS))
        cursor.execute('UPDATE invite_links SET uses = uses + 1 WHERE invite_code = ?', (invite_code,))
        cursor.execute('UPDATE users SET invited_by = ? WHERE user_id = ?', (referrer_id, new_user_id))
        conn.commit()
        conn.close()
        self.add_coins(referrer_id, REFERRAL_BONUS, 'referral_bonus', f"دعوت {new_user_id}")
        return referrer_id

    def is_owner(self, user_id: int) -> bool:
        return user_id == self.owner_id

    # ──────────────────────────────
    #        کیبوردها
    # ──────────────────────────────
    def create_main_keyboard(self, is_owner=False, has_selfbot=False):
        keyboard = []
        if has_selfbot:
            keyboard.append([InlineKeyboardButton("👤 پنل سلف من", callback_data="selfbot_panel")])
        keyboard.append([InlineKeyboardButton("🚀 فعال‌سازی سلف", callback_data="activate"), InlineKeyboardButton("💰 خرید سکه", callback_data="buy_coins")])
        keyboard.append([InlineKeyboardButton("📊 آمار من", callback_data="stats"), InlineKeyboardButton("🎫 لینک دعوت", callback_data="invite")])
        keyboard.append([InlineKeyboardButton("🛟 پشتیبانی", url=SUPPORT_LINK)])
        if is_owner:
            keyboard.insert(-1, [InlineKeyboardButton("👑 پنل ادمین", callback_data="admin_panel")])
        return InlineKeyboardMarkup(keyboard)

    def create_selfbot_keyboard(self, row):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f"{'🟢' if row['timename'] else '🔴'} ساعت در نام", callback_data="sb_time_name"), InlineKeyboardButton(f"{'🟢' if row['timebio'] else '🔴'} ساعت در بیو", callback_data="sb_time_bio")],
            [InlineKeyboardButton("🎨 انتخاب فونت", callback_data="sb_font"), InlineKeyboardButton("🔄 بروزرسانی آنی", callback_data="sb_refresh_time")],
            [InlineKeyboardButton(f"{'🟢' if row['online_status'] else '🔴'} آنلاین دائمی", callback_data="sb_online"), InlineKeyboardButton(f"{'🟢' if row['typing_action'] else '🔴'} اکشن تایپ", callback_data="sb_typing")],
            [InlineKeyboardButton(f"{'🟢' if row['hidden_typing'] else '🔴'} مخفی تایپ", callback_data="sb_hidden_typing"), InlineKeyboardButton(f"{'🟢' if row['read_receipts'] else '🔴'} خواندن خودکار", callback_data="sb_read")],
            [InlineKeyboardButton(f"{'🟢' if row['forward_pm'] else '🔴'} فوروارد پیوی", callback_data="sb_forward"), InlineKeyboardButton("💌 ارسال پیام", callback_data="sb_send_pm")],
            [InlineKeyboardButton(f"{'🟢' if row['auto_reply'] else '🔴'} پاسخ خودکار", callback_data="sb_auto_reply"), InlineKeyboardButton("✏️ تنظیم پاسخ", callback_data="sb_set_reply")],
            [InlineKeyboardButton(f"{'🟢' if row['anti_delete'] else '🔴'} آنتی حذف", callback_data="sb_anti_delete")],
            [InlineKeyboardButton("💖 لیست کراش", callback_data="sb_crash"), InlineKeyboardButton("😈 لیست دشمن", callback_data="sb_enemy")],
            [InlineKeyboardButton("➕ افزودن کراش", callback_data="sb_add_crash"), InlineKeyboardButton("➕ افزودن دشمن", callback_data="sb_add_enemy")],
            [InlineKeyboardButton("📱 نشست‌ها", callback_data="sb_sessions"), InlineKeyboardButton("ℹ️ اطلاعات من", callback_data="sb_info")],
            [InlineKeyboardButton("❌ حذف سلف", callback_data="sb_logout")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back")]
        ])

    def create_font_keyboard(self, current_font):
        keyboard = []
        for i, font in enumerate(FONTS, 1):
            sample = "12:34".translate(str.maketrans("0123456789", font))
            check = "✅ " if i == current_font else ""
            keyboard.append([InlineKeyboardButton(f"{check}فونت {i}: {sample}", callback_data=f"font_{i}")])
        keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="sb_back_panel")])
        return InlineKeyboardMarkup(keyboard)

    def create_admin_keyboard(self):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ افزودن سکه", callback_data="admin_add"), InlineKeyboardButton("➖ کسر سکه", callback_data="admin_deduct")],
            [InlineKeyboardButton("👤 اطلاعات کاربر", callback_data="admin_info"), InlineKeyboardButton("📊 آمار ربات", callback_data="admin_stats")],
            [InlineKeyboardButton("🛒 خریدهای در انتظار", callback_data="admin_pending")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back")]
        ])

    def create_back_keyboard(self):
        return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="back")]])

    def create_code_keyboard(self, current_code=""):
        display_code = current_code if current_code else "•••••"
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f"🔢 کد فعلی: {display_code}", callback_data="display")],
            [InlineKeyboardButton("1", callback_data="1"), InlineKeyboardButton("2", callback_data="2"), InlineKeyboardButton("3", callback_data="3")],
            [InlineKeyboardButton("4", callback_data="4"), InlineKeyboardButton("5", callback_data="5"), InlineKeyboardButton("6", callback_data="6")],
            [InlineKeyboardButton("7", callback_data="7"), InlineKeyboardButton("8", callback_data="8"), InlineKeyboardButton("9", callback_data="9")],
            [InlineKeyboardButton("🗑 حذف", callback_data="delete"), InlineKeyboardButton("0", callback_data="0"), InlineKeyboardButton("✅ تایید", callback_data="submit")]
        ])

    def create_coin_keyboard(self, current_amount=""):
        display_amount = current_amount if current_amount else "0"
        price = int(current_amount or 0) * COIN_PRICE
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f"💌 تعداد: {display_amount} سکه  |  💰 {price:,} تومان", callback_data="display_coins")],
            [InlineKeyboardButton("1", callback_data="coin_1"), InlineKeyboardButton("2", callback_data="coin_2"), InlineKeyboardButton("3", callback_data="coin_3")],
            [InlineKeyboardButton("4", callback_data="coin_4"), InlineKeyboardButton("5", callback_data="coin_5"), InlineKeyboardButton("6", callback_data="coin_6")],
            [InlineKeyboardButton("7", callback_data="coin_7"), InlineKeyboardButton("8", callback_data="coin_8"), InlineKeyboardButton("9", callback_data="coin_9")],
            [InlineKeyboardButton("🗑 حذف", callback_data="coin_delete"), InlineKeyboardButton("0", callback_data="coin_0"), InlineKeyboardButton("✅ تایید", callback_data="coin_confirm")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back")]
        ])

    # ──────────────────────────────
    #        ثبت هندلرها
    # ──────────────────────────────
    def setup_handlers(self):
        app = self.application
        
        app.add_handler(CommandHandler("start", self.start))
        app.add_handler(CommandHandler("cancel", self.cancel))
        app.add_handler(CommandHandler("id", self.get_user_id_cmd))
        app.add_handler(CommandHandler("addcoins", self.add_coins_cmd))
        app.add_handler(CommandHandler("kasr", self.kasr_coins_cmd))
        app.add_handler(CommandHandler("backup", self.backup_cmd))
        
        # دریافت رسید
        app.add_handler(MessageHandler(filters.PHOTO | filters.Document.IMAGE, self.handle_receipt))
        
        conv = ConversationHandler(
            entry_points=[
                CallbackQueryHandler(self.start_activation, pattern='^activate$'),
                CallbackQueryHandler(self.start_add_crash, pattern='^sb_add_crash$'),
                CallbackQueryHandler(self.start_add_enemy, pattern='^sb_add_enemy$'),
                CallbackQueryHandler(self.start_send_pm, pattern='^sb_send_pm$'),
                CallbackQueryHandler(self.start_set_reply, pattern='^sb_set_reply$'),
            ],
            states={
                GET_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.get_phone_number)],
                GET_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.get_password)],
                ADD_CRASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_add_crash)],
                ADD_ENEMY: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_add_enemy)],
                SEND_PM: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_send_pm)],
                SET_AUTOREPLY: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_set_reply)],
            },
            fallbacks=[CommandHandler('cancel', self.cancel)],
            per_message=False
        )
        app.add_handler(conv)
        
        app.add_handler(CallbackQueryHandler(self.handle_code_callbacks, pattern='^(display|submit|delete|[0-9])$'))
        app.add_handler(CallbackQueryHandler(self.handle_purchase_decision, pattern='^(approve_|reject_)'))
        app.add_handler(CallbackQueryHandler(self.handle_main_callbacks))

    async def backup_cmd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self.is_owner(update.effective_user.id): return
        try:
            await update.message.reply_document(
                document=open(self.db_path, 'rb'),
                filename=f"users_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db",
                caption="💾 بکاپ دیتابیس"
            )
        except Exception as e:
            await update.message.reply_text(f"❌ {e}")

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        user_id = user.id
        self.ensure_user(user_id, user.username, user.first_name)

        row = self.get_user(user_id)
        is_new = row is not None and row['coins'] == 0

        if context.args and len(context.args) > 0:
            referrer_id = self.process_referral(user_id, context.args[0])
            if referrer_id:
                try: await context.bot.send_message(chat_id=referrer_id, text=f"🎉 **دعوت موفق!** +{REFERRAL_BONUS} سکه")
                except: pass

        if is_new and not self.is_owner(user_id):
            self.add_coins(user_id, WELCOME_BONUS, 'welcome_bonus', 'هدیه')

        row = self.get_user(user_id)
        has_selfbot = row and row['is_selfbot_active']
        
        await update.message.reply_text(
            "💡 **پنل کاربری**\n\nاز منوی زیر انتخاب کن 👇", 
            reply_markup=self.create_main_keyboard(self.is_owner(user_id), has_selfbot), 
            parse_mode=ParseMode.MARKDOWN
        )

    async def start_activation(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id

        row = self.get_user(user_id)
        
        if row and row['session_string']:
            await query.edit_message_text("🔄 در حال اتصال...")
            success = await self.connect_user_session(user_id, row['session_string'], row['phone'])
            if success:
                await query.edit_message_text("✅ **سلف با سشن قبلی وصل شد!**", reply_markup=self.create_main_keyboard(self.is_owner(user_id), True), parse_mode=ParseMode.MARKDOWN)
                return ConversationHandler.END
            else:
                self.update_user(user_id, is_selfbot_active=0, session_string=None)
                await query.edit_message_text("⚠️ **سشن منقضی شده**\n\nدوباره شماره بفرست:", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
                return GET_PHONE

        balance = self.get_coins(user_id)
        if balance < SELF_ACTIVATION_COST:
            await query.edit_message_text(
                f"❌ **موجودی کافی نیست!**\n\n💰 `{balance}` سکه\n💸 نیاز: `{SELF_ACTIVATION_COST}`",
                reply_markup=self.create_main_keyboard(self.is_owner(user_id)), parse_mode=ParseMode.MARKDOWN
            )
            return ConversationHandler.END

        await query.edit_message_text(
            "📱 **شماره تلفن:**\n\nفرمت: `+989123456789`\n\n/cancel = انصراف",
            reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN
        )
        return GET_PHONE

    async def get_phone_number(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_input = update.message.text.strip()
        user_id = update.message.from_user.id
        digits = ''.join(filter(str.isdigit, user_input))

        if digits.startswith('98') and len(digits) == 12: phone = '+' + digits
        elif digits.startswith('09') and len(digits) == 11: phone = '+98' + digits[1:]
        elif digits.startswith('9') and len(digits) == 10: phone = '+98' + digits
        else:
            await update.message.reply_text("❌ **شماره نامعتبر!**\n`+989123456789`", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
            return GET_PHONE

        processing = await update.message.reply_text("⏳ ارسال کد...")

        try:
            client = TelegramClient(StringSession(), API_ID, API_HASH)
            await client.connect()
            result = await client.send_code_request(phone)
            
            self.user_sessions[user_id] = {
                'phone': phone, 'phone_code_hash': result.phone_code_hash,
                'client': client, 'entered_code': ''
            }
            
            await processing.edit_text(
                "🔓 **کد ارسال شد!**\n\nکد ۵ رقمی:",
                reply_markup=self.create_code_keyboard(), parse_mode=ParseMode.MARKDOWN
            )
            return ConversationHandler.END
        except Exception as e:
            err = str(e)
            if "FLOOD" in err: msg = "⚠️ صبر کن."
            elif "PHONE_NUMBER_INVALID" in err: msg = "❌ نامعتبر."
            elif "PHONE_NUMBER_BANNED" in err: msg = "🚫 مسدود."
            else: msg = f"❌ {err}"
            await processing.edit_text(msg, reply_markup=self.create_back_keyboard())
            return GET_PHONE

    async def get_password(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        password = update.message.text.strip()
        user_id = update.message.from_user.id
        
        if user_id not in self.user_sessions:
            await update.message.reply_text("❌ سشن منقضی. /start")
            return ConversationHandler.END
        
        session = self.user_sessions[user_id]
        try:
            await session['client'].sign_in(password=password)
            session_string = session['client'].session.save()
            success = await self.save_selfbot_session(user_id, session_string, session['phone'])
            
            if success:
                self.deduct_coins(user_id, SELF_ACTIVATION_COST, 'selfbot_activation', 'فعال‌سازی')
                await update.message.reply_text("🎉 **سلف فعال شد!**\n💰 ۳ سکه کسر شد.", reply_markup=self.create_main_keyboard(self.is_owner(user_id), True), parse_mode=ParseMode.MARKDOWN)
            else:
                await update.message.reply_text("⚠️ خطا!")
            
            if user_id in self.user_sessions:
                try: await self.user_sessions[user_id]['client'].disconnect()
                except: pass
                del self.user_sessions[user_id]
            return ConversationHandler.END
        except Exception as e:
            await update.message.reply_text(f"❌ {e}")
            return ConversationHandler.END

    async def handle_code_callbacks(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id
        data = query.data

        if user_id not in self.user_sessions:
            return

        session = self.user_sessions[user_id]

        if data == "delete":
            session['entered_code'] = ''
            await query.edit_message_text("🗑 پاک شد:", reply_markup=self.create_code_keyboard())
        elif data == "display":
            await query.answer(f"کد: {session['entered_code'] or 'خالی'}")
        elif data in "0123456789" and len(data) == 1:
            if len(session['entered_code']) < 5:
                session['entered_code'] += data
                code = session['entered_code']
                remaining = 5 - len(code)
                msg = f"✅ کد: `{code}`\n📲 تایید:" if remaining == 0 else f"🔢 `{code}{'•' * remaining}`\n📝 {remaining} رقم"
                await query.edit_message_text(msg, reply_markup=self.create_code_keyboard(code), parse_mode=ParseMode.MARKDOWN)
            else:
                await query.answer("کد پر شده!")
        elif data == "submit":
            code = session['entered_code']
            if len(code) != 5:
                await query.answer("کد ۵ رقمی!", show_alert=True)
                return
            
            await query.edit_message_text("⏳ بررسی...")
            client = session['client']
            
            try:
                await client.sign_in(phone=session['phone'], code=code, phone_code_hash=session['phone_code_hash'])
                session_string = client.session.save()
                success = await self.save_selfbot_session(user_id, session_string, session['phone'])
                
                if success:
                    self.deduct_coins(user_id, SELF_ACTIVATION_COST, 'selfbot_activation', 'فعال‌سازی')
                    await query.message.reply_text(f"🎉 **سلف فعال شد!**\n✅ متصل شد\n💰 `{SELF_ACTIVATION_COST}` سکه کسر شد", reply_markup=self.create_main_keyboard(self.is_owner(user_id), True), parse_mode=ParseMode.MARKDOWN)
                else:
                    await query.message.reply_text("⚠️ خطا!")
                
                if user_id in self.user_sessions:
                    try: await self.user_sessions[user_id]['client'].disconnect()
                    except: pass
                    del self.user_sessions[user_id]
            
            except Exception as e:
                err = str(e)
                if "SESSION_PASSWORD_NEEDED" in err:
                    await query.edit_message_text("🔐 **رمز دو مرحله‌ای:**\n\nرمز بفرست:")
                    return GET_PASSWORD
                elif "CODE_INVALID" in err:
                    session['entered_code'] = ''
                    await query.edit_message_text("❌ نامعتبر:", reply_markup=self.create_code_keyboard())
                else:
                    await query.edit_message_text(f"❌ {err}")
                    if user_id in self.user_sessions:
                        try: await self.user_sessions[user_id]['client'].disconnect()
                        except: pass
                        del self.user_sessions[user_id]

    async def save_selfbot_session(self, user_id: int, session_string: str, phone: str) -> bool:
        try:
            self.update_user(user_id, session_string=session_string, phone=phone, is_selfbot_active=1)
            return await self.connect_user_session(user_id, session_string, phone)
        except Exception as e:
            logger.error(f"خطا: {e}")
            return False

    async def connect_user_session(self, user_id: int, session_string: str, phone: str) -> bool:
        try:
            if user_id in self.user_clients:
                try: await self.user_clients[user_id].disconnect()
                except: pass
            
            client = TelegramClient(StringSession(session_string), API_ID, API_HASH)
            await client.connect()
            
            if not await client.is_user_authorized(): return False
            me = await client.get_me()
            if not me: return False
            
            self.user_clients[user_id] = client
            self.update_user(user_id, is_selfbot_active=1)
            
            if not getattr(client, '_handlers_registered', False):
                self._register_input_handlers(client, user_id)
                client._handlers_registered = True
            
            if user_id not in self.bg_tasks:
                self.bg_tasks[user_id] = [
                    asyncio.create_task(self._time_updater(user_id)),
                    asyncio.create_task(self._online_keeper(user_id)),
                ]
            
            logger.info(f"✅ {phone} متصل | user: {user_id}")
            return True
        except Exception as e:
            logger.error(f"خطا: {e}")
            return False

    def _register_input_handlers(self, client, user_id):
        @client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
        async def input_handler(event):
            try:
                if event.sender_id == user_id: return
                row = self.get_user(user_id)
                if not row or not row['is_selfbot_active']: return
                
                self.update_user(user_id, stats_messages=(row['stats_messages'] or 0) + 1)
                sender = await event.get_sender()
                if not sender: return
                
                text = event.raw_text or ""
                if not text: return
                
                if row['forward_pm']:
                    try:
                        await self.application.bot.send_message(
                            chat_id=user_id,
                            text=f"📨 **پیام جدید**\n\n👤 {sender.first_name or '---'}\n🆔 `{sender.id}`\n📱 @{sender.username or 'ندارد'}\n\n💬 {text[:500]}",
                            parse_mode=ParseMode.MARKDOWN
                        )
                    except: pass
                
                if row['auto_reply'] and row['auto_reply_text']:
                    try:
                        await asyncio.sleep(random.uniform(1, 3))
                        await client.send_message(event.chat_id, row['auto_reply_text'])
                    except: pass
                
                if row['read_receipts']:
                    try: await client.send_read_acknowledge(event.chat_id)
                    except: pass
            except: pass

    async def _time_updater(self, user_id: int):
        while True:
            try:
                await asyncio.sleep(60)
                if user_id not in self.user_clients: break
                row = self.get_user(user_id)
                if not row or not row['is_selfbot_active']: break
                client = self.user_clients[user_id]
                
                if row['timename'] or row['timebio']:
                    now = datetime.now().strftime("%H:%M")
                    idx = (row['font'] or 1) - 1
                    ft = now.translate(str.maketrans("0123456789", FONTS[idx])) if 0 <= idx < len(FONTS) else now
                    try:
                        if row['timename']:
                            await client(functions.account.UpdateProfileRequest(last_name=ft))
                        if row['timebio']:
                            orig = row['original_bio'] or ''
                            await client(functions.account.UpdateProfileRequest(about=f"{orig} {ft}".strip()[:70]))
                    except: pass
            except asyncio.CancelledError: break
            except: await asyncio.sleep(60)

    async def _online_keeper(self, user_id: int):
        while True:
            try:
                await asyncio.sleep(60)
                if user_id not in self.user_clients: break
                row = self.get_user(user_id)
                if not row or not row['is_selfbot_active']: break
                if row['online_status']:
                    try: await self.user_clients[user_id](UpdateStatusRequest(offline=False))
                    except: pass
            except asyncio.CancelledError: break
            except: await asyncio.sleep(60)

    async def update_time_now(self, user_id: int):
        try:
            if user_id not in self.user_clients: return False
            row = self.get_user(user_id)
            if not row: return False
            client = self.user_clients[user_id]
            now = datetime.now().strftime("%H:%M")
            idx = (row['font'] or 1) - 1
            ft = now.translate(str.maketrans("0123456789", FONTS[idx])) if 0 <= idx < len(FONTS) else now
            if row['timename']:
                await client(functions.account.UpdateProfileRequest(last_name=ft))
            if row['timebio']:
                orig = row['original_bio'] or ''
                await client(functions.account.UpdateProfileRequest(about=f"{orig} {ft}".strip()[:70]))
            return True
        except: return False

    async def safe_edit(self, query, text, keyboard=None):
        try:
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            if "not modified" not in str(e).lower():
                logger.error(f"safe_edit: {e}")

    async def handle_main_callbacks(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        data = query.data
        user_id = query.from_user.id
        is_admin = self.is_owner(user_id)
        row = self.get_user(user_id)
        has_selfbot = row and row['is_selfbot_active']

        if data == "activate":
            await query.answer()
            return

        await query.answer()

        if data == "back":
            await self.safe_edit(query, "💡 **پنل کاربری**\n\nاز منو انتخاب کن 👇", self.create_main_keyboard(is_admin, has_selfbot))
        
        elif data == "selfbot_panel":
            if not has_selfbot:
                await query.answer("❌ اول سلف رو فعال کن!", show_alert=True)
                return
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_back_panel":
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_time_name":
            new_val = 0 if row['timename'] else 1
            self.update_user(user_id, timename=new_val)
            if new_val:
                if user_id in self.user_clients:
                    try:
                        me = await self.user_clients[user_id].get_me()
                        self.update_user(user_id, original_last_name=me.last_name or "")
                    except: pass
                ok = await self.update_time_now(user_id)
                await query.answer("✅ روشن شد" if ok else "✅ روشن - سلف متصل نیست", show_alert=True)
            else:
                if user_id in self.user_clients:
                    try:
                        orig = self.get_user(user_id)['original_last_name'] or ""
                        await self.user_clients[user_id](functions.account.UpdateProfileRequest(last_name=orig))
                    except: pass
                await query.answer("❌ خاموش شد", show_alert=True)
            row = self.get_user(user_id)
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_time_bio":
            new_val = 0 if row['timebio'] else 1
            self.update_user(user_id, timebio=new_val)
            if new_val:
                if user_id in self.user_clients:
                    try:
                        full = await self.user_clients[user_id](GetFullUserRequest('me'))
                        self.update_user(user_id, original_bio=full.full_user.about or "")
                    except: pass
                ok = await self.update_time_now(user_id)
                await query.answer("✅ روشن شد" if ok else "✅ روشن - سلف متصل نیست", show_alert=True)
            else:
                if user_id in self.user_clients:
                    try:
                        orig = self.get_user(user_id)['original_bio'] or ""
                        await self.user_clients[user_id](functions.account.UpdateProfileRequest(about=orig))
                    except: pass
                await query.answer("❌ خاموش شد", show_alert=True)
            row = self.get_user(user_id)
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_refresh_time":
            ok = await self.update_time_now(user_id)
            await query.answer("✅ آپدیت شد!" if ok else "❌ خطا", show_alert=True)
        
        elif data == "sb_online":
            new_val = 0 if row['online_status'] else 1
            self.update_user(user_id, online_status=new_val)
            if new_val and user_id in self.user_clients:
                try: await self.user_clients[user_id](UpdateStatusRequest(offline=False))
                except: pass
            await query.answer(f"{'✅ روشن' if new_val else '❌ خاموش'}", show_alert=True)
            row = self.get_user(user_id)
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data in ["sb_typing", "sb_hidden_typing", "sb_read", "sb_forward", "sb_auto_reply", "sb_anti_delete"]:
            field = data.replace("sb_", "")
            mapping = {"typing": "typing_action", "hidden_typing": "hidden_typing", "read": "read_receipts",
                       "forward": "forward_pm", "auto_reply": "auto_reply", "anti_delete": "anti_delete"}
            col = mapping.get(field, field)
            new_val = 0 if row[col] else 1
            self.update_user(user_id, **{col: new_val})
            await query.answer(f"{'✅ روشن' if new_val else '❌ خاموش'}", show_alert=True)
            row = self.get_user(user_id)
            await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_font":
            await self.safe_edit(query, "🎨 **انتخاب فونت**\n\n✅ = فعال", self.create_font_keyboard(row['font'] or 1))
        
        elif data.startswith("font_"):
            num = int(data.split("_")[1])
            if 1 <= num <= len(FONTS):
                self.update_user(user_id, font=num)
                row = self.get_user(user_id)
                if row['timename'] or row['timebio']:
                    await self.update_time_now(user_id)
                sample = "12:34".translate(str.maketrans("0123456789", FONTS[num-1]))
                await query.answer(f"✅ فونت {num}: {sample}", show_alert=True)
                row = self.get_user(user_id)
                await self.safe_edit(query, "🎭 **پنل سلف شما**", self.create_selfbot_keyboard(row))
        
        elif data == "sb_crash":
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT user_id FROM crash WHERE owner_id = ?', (user_id,))
            rows = cursor.fetchall()
            conn.close()
            txt = "💖 **کراش:**\n\n" + "\n".join(f"• [{r['user_id']}](tg://user?id={r['user_id']})" for r in rows) if rows else "💔 **خالی**"
            await self.safe_edit(query, txt, self.create_selfbot_keyboard(row))
        
        elif data == "sb_enemy":
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT user_id FROM enemy WHERE owner_id = ?', (user_id,))
            rows = cursor.fetchall()
            conn.close()
            txt = "😈 **دشمن:**\n\n" + "\n".join(f"• [{r['user_id']}](tg://user?id={r['user_id']})" for r in rows) if rows else "😇 **خالی**"
            await self.safe_edit(query, txt, self.create_selfbot_keyboard(row))
        
        elif data == "sb_sessions":
            if user_id not in self.user_clients:
                await query.answer("❌ متصل نیست!", show_alert=True)
                return
            try:
                result = await self.user_clients[user_id](functions.account.GetAuthorizationsRequest())
                txt = "📱 **نشست‌ها**\n\n"
                for i, a in enumerate(result.authorizations, 1):
                    txt += f"**#{i}** {a.device_model or '?'} - {a.country or '?'}\n"
                await self.safe_edit(query, txt, self.create_selfbot_keyboard(row))
            except Exception as e:
                await query.answer(f"❌ {e}", show_alert=True)
        
        elif data == "sb_info":
            if user_id not in self.user_clients:
                await query.answer("❌ متصل نیست!", show_alert=True)
                return
            try:
                me = await self.user_clients[user_id].get_me()
                txt = f"ℹ️ `{me.id}`\n👤 {me.first_name or '---'}\n📛 {me.last_name or '---'}\n🔗 @{me.username or '---'}\n📱 `{row['phone']}`\n\n💬 {row['stats_messages'] or 0} پیام"
                await self.safe_edit(query, txt, self.create_selfbot_keyboard(row))
            except Exception as e:
                await query.answer(f"❌ {e}", show_alert=True)
        
        elif data == "sb_logout":
            if user_id in self.user_clients:
                try: await self.user_clients[user_id].disconnect()
                except: pass
                del self.user_clients[user_id]
            if user_id in self.bg_tasks:
                for t in self.bg_tasks[user_id]: t.cancel()
                del self.bg_tasks[user_id]
            self.update_user(user_id, is_selfbot_active=0, session_string=None, timename=0, timebio=0)
            await self.safe_edit(query, "❌ **سلف حذف شد!**", self.create_main_keyboard(is_admin, False))
        
        elif data == "stats":
            coins = row['coins'] if row else 0
            await self.safe_edit(query, f"📊 **آمار**\n\n💰 `{coins:,}` سکه\n💎 `{coins * COIN_PRICE:,}` تومان", self.create_main_keyboard(is_admin, has_selfbot))
        
        elif data == "invite":
            link = self.get_or_create_invite_link(user_id, context.bot.username)
            await self.safe_edit(query, f"🎫 `{link}`", self.create_main_keyboard(is_admin, has_selfbot))
        
        elif data == "buy_coins":
            context.user_data['coin_amount'] = ''
            await self.safe_edit(query, f"💌 **خرید سکه**\n\n💰 هر سکه: `{COIN_PRICE}` تومان\n⌨️ تعداد:", self.create_coin_keyboard())
        
        elif data.startswith("coin_"):
            await self.handle_coin_purchase(query, context, data)
        
        elif data == "admin_panel" and is_admin:
            await self.safe_edit(query, "👑 **پنل ادمین**", self.create_admin_keyboard())
        
        elif data == "admin_stats" and is_admin:
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) as c FROM users')
            users = cursor.fetchone()['c']
            cursor.execute('SELECT COUNT(*) as c FROM users WHERE is_selfbot_active = 1')
            active = cursor.fetchone()['c']
            cursor.execute("SELECT COUNT(*) as c FROM purchases WHERE status = 'pending'")
            pending = cursor.fetchone()['c']
            conn.close()
            await self.safe_edit(query, f"📊 **آمار**\n\n👥 `{users}`\n🚀 `{active}`\n🛒 `{pending}`", self.create_admin_keyboard())
        
        elif data == "admin_pending" and is_admin:
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM purchases WHERE status = 'pending' ORDER BY id DESC LIMIT 10")
            rows = cursor.fetchall()
            conn.close()
            if not rows:
                await query.answer("✅ هیچ خرید در انتظاری نیست", show_alert=True)
                return
            txt = "🛒 **در انتظار:**\n\n"
            for r in rows:
                txt += f"#{r['id']} - `{r['user_id']}` - {r['coin_amount']} سکه\n"
            await self.safe_edit(query, txt, self.create_admin_keyboard())
        
        elif data in ["admin_add", "admin_deduct", "admin_info"] and is_admin:
            cmd = "/addcoins 50" if data == "admin_add" else ("/kasr 50" if data == "admin_deduct" else "/id")
            await self.safe_edit(query, f"ℹ️ روی پیام کاربر ریپلای کن:\n`{cmd}`", self.create_admin_keyboard())

    async def handle_coin_purchase(self, query, context, data):
        if 'coin_amount' not in context.user_data:
            context.user_data['coin_amount'] = ''
        amount_str = context.user_data['coin_amount']

        if data == "coin_delete":
            context.user_data['coin_amount'] = ''
            await self.safe_edit(query, "💌 **خرید**\n\n⌨️ تعداد:", self.create_coin_keyboard())
        
        elif data == "coin_confirm":
            if not amount_str or int(amount_str) <= 0:
                await query.answer("❌ تعداد معتبر!", show_alert=True)
                return
            count = int(amount_str)
            if count > MAX_COINS_PER_PURCHASE:
                await query.answer(f"❌ حداکثر {MAX_COINS_PER_PURCHASE}!", show_alert=True)
                return
            total = count * COIN_PRICE
            
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute('INSERT INTO purchases (user_id, coin_amount, total_price) VALUES (?, ?, ?)',
                          (query.from_user.id, count, total))
            purchase_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            context.user_data['coin_amount'] = ''
            
            await self.safe_edit(
                query,
                f"💌 **پرداخت**\n\n"
                f"━━━━━━━━━━━━━━━\n"
                f"💳 **شماره کارت:**\n`{CARD_NUMBER}`\n\n"
                f"👤 **به نام:** {CARD_OWNER}\n"
                f"━━━━━━━━━━━━━━━\n\n"
                f"🩸 **مبلغ:** `{total:,}` تومان\n"
                f"💌 **تعداد:** `{count}` سکه\n"
                f"🔖 **شناسه:** `#{purchase_id}`\n\n"
                f"📸 **عکس رسید رو همین‌جا بفرست:**\n\n"
                f"⚠️ بدون رسید، خرید تایید نمی‌شه!",
                InlineKeyboardMarkup([[InlineKeyboardButton("❌ انصراف", callback_data="back")]])
            )
        
        elif data.startswith("coin_"):
            digit = data.split("_")[1]
            new_str = amount_str + digit
            if len(new_str) > 4:
                await query.answer("❌ حداکثر ۴ رقم!", show_alert=True)
                return
            context.user_data['coin_amount'] = new_str
            price = int(new_str) * COIN_PRICE
            await self.safe_edit(query, f"💌 **تعداد:** `{new_str}`\n💰 **قیمت:** `{price:,}`", self.create_coin_keyboard(new_str))

    async def handle_receipt(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        user_id = user.id
        message = update.message
        
        file_id = None
        if message.photo:
            file_id = message.photo[-1].file_id
        elif message.document and (message.document.mime_type or "").startswith("image/"):
            file_id = message.document.file_id
        
        if not file_id:
            await message.reply_text("❌ فقط عکس رسید بفرست.")
            return
        
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM purchases WHERE user_id = ? AND status = 'pending' AND receipt_file_id IS NULL ORDER BY id DESC LIMIT 1",
            (user_id,)
        )
        purchase = cursor.fetchone()
        
        if not purchase:
            conn.close()
            await message.reply_text("❌ **هیچ خرید در انتظاری نداری!**\n\nاول از منو خرید رو شروع کن.")
            return
        
        pid = purchase['id']
        coins = purchase['coin_amount']
        total = purchase['total_price']
        
        cursor.execute('UPDATE purchases SET receipt_file_id = ? WHERE id = ?', (file_id, pid))
        conn.commit()
        conn.close()
        
        admin_text = (
            f"🛒 **درخواست خرید**\n\n"
            f"👤 {user.first_name or '---'}\n"
            f"🆔 `{user_id}`\n"
            f"📱 @{user.username or 'ندارد'}\n\n"
            f"💌 **{coins}** سکه\n"
            f"🩸 **{total:,}** تومان\n"
            f"🔖 `#{pid}`\n"
            f"⏰ `{datetime.now().strftime('%H:%M:%S')}`"
        )
        
        admin_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ تایید", callback_data=f"approve_{pid}"),
            InlineKeyboardButton("❌ رد", callback_data=f"reject_{pid}")
        ]])
        
        try:
            await context.bot.send_photo(
                chat_id=self.owner_id, photo=file_id, caption=admin_text,
                reply_markup=admin_kb, parse_mode=ParseMode.MARKDOWN
            )
            await message.reply_text(
                f"✅ **رسید دریافت شد!**\n\n🔖 `#{pid}`\n💌 `{coins}` سکه\n🩸 `{total:,}` تومان\n\n⏳ در حال بررسی توسط ادمین...",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"خطا: {e}")
            await message.reply_text("❌ خطا در ارسال. با پشتیبانی تماس بگیر.")

    async def handle_purchase_decision(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        
        if not self.is_owner(query.from_user.id):
            await query.answer("⛔ فقط ادمین!", show_alert=True)
            return
        
        data = query.data
        pid = int(data.split("_")[1])
        
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM purchases WHERE id = ?', (pid,))
        p = cursor.fetchone()
        
        if not p:
            conn.close()
            await query.answer("❌ پیدا نشد!", show_alert=True)
            return
        if p['status'] != 'pending':
            conn.close()
            await query.answer(f"❌ قبلاً بررسی شده: {p['status']}", show_alert=True)
            return
        
        buyer_id = p['user_id']
        coins = p['coin_amount']
        
        if data.startswith("approve_"):
            self.add_coins(buyer_id, coins, 'purchase', f'خرید #{pid}')
            cursor.execute("UPDATE purchases SET status = 'approved', approved_at = ? WHERE id = ?",
                          (datetime.now().isoformat(), pid))
            conn.commit()
            conn.close()
            
            try: await query.edit_message_caption(caption=f"{query.message.caption}\n\n✅ **تایید شد** - {coins} سکه اضافه شد", parse_mode=ParseMode.MARKDOWN)
            except: pass
            try: await context.bot.send_message(chat_id=buyer_id, text=f"🎉 **خرید تایید شد!**\n\n💌 `{coins}` سکه اضافه شد\n🔖 `#{pid}`\n💰 موجودی: `{self.get_coins(buyer_id):,}`", parse_mode=ParseMode.MARKDOWN)
            except: pass
        else:
            cursor.execute("UPDATE purchases SET status = 'rejected' WHERE id = ?", (pid,))
            conn.commit()
            conn.close()
            
            try: await query.edit_message_caption(caption=f"{query.message.caption}\n\n❌ **رد شد**", parse_mode=ParseMode.MARKDOWN)
            except: pass
            try: await context.bot.send_message(chat_id=buyer_id, text=f"❌ **خرید رد شد**\n\n🔖 `#{pid}`\n\n📞 {SUPPORT_LINK}", parse_mode=ParseMode.MARKDOWN)
            except: pass

    async def start_add_crash(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.answer()
        await update.callback_query.edit_message_text("💖 **آیدی:**\n\n/cancel = انصراف", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
        return ADD_CRASH

    async def handle_add_crash(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try: tid = int(update.message.text.strip())
        except:
            await update.message.reply_text("❌ عدد:", reply_markup=self.create_back_keyboard())
            return ADD_CRASH
        uid = update.message.from_user.id
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('INSERT OR IGNORE INTO crash (user_id, owner_id) VALUES (?, ?)', (tid, uid))
        conn.commit()
        conn.close()
        await update.message.reply_text(f"✅ `{tid}` اضافه شد", reply_markup=self.create_selfbot_keyboard(self.get_user(uid)))
        return ConversationHandler.END

    async def start_add_enemy(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.answer()
        await update.callback_query.edit_message_text("😈 **آیدی:**\n\n/cancel = انصراف", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
        return ADD_ENEMY

    async def handle_add_enemy(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try: tid = int(update.message.text.strip())
        except:
            await update.message.reply_text("❌ عدد:", reply_markup=self.create_back_keyboard())
            return ADD_ENEMY
        uid = update.message.from_user.id
        conn = self.get_db()
        cursor = conn.cursor()
        cursor.execute('INSERT OR IGNORE INTO enemy (user_id, owner_id) VALUES (?, ?)', (tid, uid))
        conn.commit()
        conn.close()
        await update.message.reply_text(f"✅ `{tid}` اضافه شد", reply_markup=self.create_selfbot_keyboard(self.get_user(uid)))
        return ConversationHandler.END

    async def start_send_pm(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.answer()
        await update.callback_query.edit_message_text("💌 **فرمت: `آیدی|متن`**\n\n/cancel = انصراف", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
        return SEND_PM

    async def handle_send_pm(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.message.from_user.id
        if uid not in self.user_clients:
            await update.message.reply_text("❌ سلف متصل نیست!")
            return ConversationHandler.END
        try:
            parts = update.message.text.split('|', 1)
            if len(parts) != 2: raise ValueError
            tid = int(parts[0].strip())
            msg = parts[1].strip()
        except:
            await update.message.reply_text("❌ فرمت اشتباه!", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
            return SEND_PM
        try:
            await self.user_clients[uid].send_message(tid, msg)
            await update.message.reply_text("✅ ارسال شد", reply_markup=self.create_selfbot_keyboard(self.get_user(uid)))
        except Exception as e:
            await update.message.reply_text(f"❌ {e}", reply_markup=self.create_selfbot_keyboard(self.get_user(uid)))
        return ConversationHandler.END

    async def start_set_reply(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.answer()
        await update.callback_query.edit_message_text("✏️ **متن پاسخ:**\n\n/cancel = انصراف", reply_markup=self.create_back_keyboard(), parse_mode=ParseMode.MARKDOWN)
        return SET_AUTOREPLY

    async def handle_set_reply(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.message.from_user.id
        text = update.message.text.strip()
        if not text:
            await update.message.reply_text("❌ متن خالی!")
            return SET_AUTOREPLY
        self.update_user(uid, auto_reply_text=text, auto_reply=1)
        await update.message.reply_text(f"✅ تنظیم شد\n💬 `{text[:100]}`", reply_markup=self.create_selfbot_keyboard(self.get_user(uid)), parse_mode=ParseMode.MARKDOWN)
        return ConversationHandler.END

    async def get_user_id_cmd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self.is_owner(update.effective_user.id): return
        if not update.message.reply_to_message:
            await update.message.reply_text("❌ ریپلای!")
            return
        t = update.message.reply_to_message.from_user
        self.ensure_user(t.id, t.username, t.first_name)
        row = self.get_user(t.id)
        await update.message.reply_text(
            f"👤 `{t.id}`\n👁 @{t.username or 'ندارد'}\n📛 {t.first_name}\n"
            f"💰 `{row['coins']:,}` سکه\n🚀 {'✅' if row['is_selfbot_active'] else '❌'}\n"
            f"💬 {row['stats_messages'] or 0} پیام",
            parse_mode=ParseMode.MARKDOWN)

    async def add_coins_cmd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self.is_owner(update.effective_user.id): return
        if not update.message.reply_to_message or not context.args: return
        try: amount = int(context.args[0])
        except: return
        t = update.message.reply_to_message.from_user
        self.ensure_user(t.id, t.username, t.first_name)
        self.add_coins(t.id, amount, 'admin_add', 'افزودن')
        await update.message.reply_text(f"✅ {amount} سکه به {t.first_name} اضافه شد")

    async def kasr_coins_cmd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self.is_owner(update.effective_user.id): return
        if not update.message.reply_to_message or not context.args: return
        try: amount = int(context.args[0])
        except: return
        t = update.message.reply_to_message.from_user
        actual = min(amount, self.get_coins(t.id))
        if actual > 0: self.deduct_coins(t.id, actual, 'admin_kasr', 'کسر')
        await update.message.reply_text(f"✅ {actual} سکه از {t.first_name} کسر شد")

    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.effective_user.id
        if uid in self.user_sessions:
            try: await self.user_sessions[uid]['client'].disconnect()
            except: pass
            del self.user_sessions[uid]
        context.user_data.clear()
        await update.message.reply_text("❌ لغو شد. /start")
        return ConversationHandler.END

    async def start_all_selfbots(self):
        try:
            conn = self.get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT user_id, session_string, phone FROM users WHERE is_selfbot_active = 1 AND session_string IS NOT NULL')
            rows = cursor.fetchall()
            conn.close()
            if not rows: return
            logger.info(f"🔄 اتصال {len(rows)} سلف...")
            for row in rows:
                await self.connect_user_session(row['user_id'], row['session_string'], row['phone'])
                await asyncio.sleep(2)
        except Exception as e:
            logger.error(f"خطا: {e}")

    def run(self):
        logger.info("🤖 ربات در حال اجراست...")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.start_all_selfbots())
        self.application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    bot = TelegramAuthBot()
    bot.run()